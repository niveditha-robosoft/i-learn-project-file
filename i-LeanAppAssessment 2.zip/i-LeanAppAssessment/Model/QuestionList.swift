//
//  QuestionList.swift
//  i-LeanAppAssessment
//
//  Created by Shrushti Shetty on 22/12/22.
//

import Foundation
class QuestionList{
    var questionId: Int
    var questionName: String
    
    init(questionId: Int, questionName: String) {
        self.questionId = questionId
        self.questionName = questionName
    }
}
