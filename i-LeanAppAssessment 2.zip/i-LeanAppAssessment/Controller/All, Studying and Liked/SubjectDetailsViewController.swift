//
//  SubjectDetailsViewController.swift
//  i-LeanAppAssessment
//
//  Created by Harsha R Mundaragi on 10/12/22.
//

import UIKit

class SubjectDetailsViewController: UIViewController {
    

    @IBOutlet weak var allButton: SkipCustomButtob!
    @IBOutlet weak var likedButton: SkipCustomButtob!
    @IBOutlet weak var studyingButton: UIButton!
    
    @IBOutlet weak var detailsOfTheSubject: UIView!
    @IBOutlet weak var studying: UIView!
    @IBOutlet weak var liked: UIView!
    
    @IBOutlet weak var subjectNAmeToShow: UILabel!
    
    var x1 = 0
    
    
    var subjectIdFromSUbjectlist = 0
    var subjectNameToSend = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isHidden = true
        tabBarController?.tabBar.isHidden = true

        subjectNAmeToShow.text = subjectNameToSend
        view.bringSubviewToFront(detailsOfTheSubject)
        detailsOfTheSubject.isHidden = false
        studying.isHidden = true
        liked.isHidden = true
        view.bringSubviewToFront(detailsOfTheSubject)
        allButton.setTitleColor(#colorLiteral(red: 0.2980392157, green: 0.5764705882, blue: 1, alpha: 1), for: .normal)
        likedButton.setTitleColor(#colorLiteral(red: 0.5568627451, green: 0.5607843137, blue: 0.5764705882, alpha: 1), for: .normal)
        studyingButton.setTitleColor(#colorLiteral(red: 0.5568627451, green: 0.5607843137, blue: 0.5764705882, alpha: 1), for: .normal)
        studying.isHidden = true
        liked.isHidden = true
        allButton.roundCorners(corners: [.bottomLeft,.topLeft], radius: 12)

        likedButton.roundCorners(corners: [.bottomRight,.topRight], radius: 12)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if let vc = segue.destination as? AboutSubjectViewController{
        vc.subIdIs = subjectIdFromSUbjectlist
            vc.subjectNameIs = subjectNameToSend
            vc.x2 = x1
        }
    }
    @IBAction func allbuttonTapped(_ sender: Any) {
        view.bringSubviewToFront(detailsOfTheSubject)
        detailsOfTheSubject.isHidden = false
        studying.isHidden = true
        liked.isHidden = true
        allButton.setTitleColor(#colorLiteral(red: 0.2980392157, green: 0.5764705882, blue: 1, alpha: 1), for: .normal)
        likedButton.setTitleColor(#colorLiteral(red: 0.5568627451, green: 0.5607843137, blue: 0.5764705882, alpha: 1), for: .normal)
        studyingButton.setTitleColor(#colorLiteral(red: 0.5568627451, green: 0.5607843137, blue: 0.5764705882, alpha: 1), for: .normal)
    }
    
    @IBAction func subjectButtonTapped(_ sender: Any) {
        view.bringSubviewToFront(studying)
        studying.isHidden = false
        detailsOfTheSubject.isHidden = true
        liked.isHidden = true
        allButton.setTitleColor(#colorLiteral(red: 0.5568627451, green: 0.5607843137, blue: 0.5764705882, alpha: 1), for: .normal)
        likedButton.setTitleColor(#colorLiteral(red: 0.5568627451, green: 0.5607843137, blue: 0.5764705882, alpha: 1), for: .normal)
        studyingButton.setTitleColor(#colorLiteral(red: 0.2980392157, green: 0.5764705882, blue: 1, alpha: 1), for: .normal)
    }
    
    @IBAction func likeButtonTapped(_ sender: Any) {
        view.bringSubviewToFront(liked)
        detailsOfTheSubject.isHidden = true
        studying.isHidden = true
        liked.isHidden = false
        allButton.setTitleColor(#colorLiteral(red: 0.5568627451, green: 0.5607843137, blue: 0.5764705882, alpha: 1), for: .normal)
        likedButton.setTitleColor(#colorLiteral(red: 0.2980392157, green: 0.5764705882, blue: 1, alpha: 1), for: .normal)
        studyingButton.setTitleColor(#colorLiteral(red: 0.5568627451, green: 0.5607843137, blue: 0.5764705882, alpha: 1), for: .normal)
    }
    
    @IBAction func backButtonTapped(_ sender: Any) {
        
        print("go to home screen")
        
        for controller in self.navigationController!.viewControllers as Array {
            
            if controller.isKind(of: TabBarViewController.self) {
                
                self.navigationController!.popToViewController(controller, animated: false)
                
                break
                
            }
            
        }
        
    }
    
}
