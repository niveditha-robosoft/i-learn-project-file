//
//  ProfileEditManager.swift
//  profile
//
//  Created by Niveditha Naik on 12/12/22.
//

import Foundation
class ProfileEditManager{
//    func apiCallForProfileDetails(){
//        let url = URL(string: "https://api.example.com/patch-endpoint")!
//        var request = URLRequest(url: url)
//        request.httpMethod = "PATCH"
//        request.httpBody = try! JSONSerialization.data(withJSONObject: jsonBody, options: [])
//        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
//        let session = URLSession.shared
//        let task = session.dataTask(with: request) { data, response, error in
//          if let data = data {
//              let response = try! JSONSerialization.jsonObject(with: data, options: [])
//            } else if let error = error {
//            
//            }
//        }
//        task.resume()
//    }
}
