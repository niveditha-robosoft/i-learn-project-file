//
//  ViewController.swift
//  i-LeanAppAssessment
//
//  Created by Harsha R Mundaragi on 06/12/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
//        hi
//        hi from feature1
// hi from feature2
        // hi from feature3
        //hi again from feature3
        //check if it is my account
    }


}

