//
//  SubjectDetailViewController.swift
//  i-LeanAppAssessment
//
//  Created by Harsha R Mundaragi on 10/12/22.
//

import Foundation
import UIKit


class SubjectDetailsViewController: <#super class#> {
    <#code#>
}
