//
//  AboutSubjectCollectionViewCell.swift
//  i-LeanAppAssessment
//
//  Created by Harsha R Mundaragi on 11/12/22.
//

import UIKit

class AboutSubjectCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var image: UIImageView!
    
    @IBOutlet weak var labelText: UILabel!
    
    
    @IBOutlet weak var backView: UIView!
    
    @IBOutlet weak var imageBackgroundView: UIView!
}
