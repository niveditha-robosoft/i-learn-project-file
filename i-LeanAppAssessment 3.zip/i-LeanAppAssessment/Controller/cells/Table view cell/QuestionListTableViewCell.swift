//
//  QuestionsListTableViewCell.swift
//  i-LeanAppAssessment
//
//  Created by Shrushti Shetty on 14/12/22.
//

import UIKit

class QuestionListTableViewCell: UITableViewCell {
     @IBOutlet weak var cardView: UIView!
     @IBOutlet weak var questionNumber: UILabel!
     @IBOutlet weak var question: UILabel!
}
