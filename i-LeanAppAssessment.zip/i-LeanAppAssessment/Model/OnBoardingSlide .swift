//
//  OnBoardingSlide .swift
//  i-LeanAppAssessment
//
//  Created by Niveditha Naik on 06/12/22.
//

import UIKit
struct OnBoardingSlide {
    let title: String
    let description: String
    let image: UIImage
    
}
