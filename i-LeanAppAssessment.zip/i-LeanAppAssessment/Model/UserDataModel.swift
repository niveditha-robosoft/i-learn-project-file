//
//  UserDataModel.swift
//  i-LeanAppAssessment
//
//  Created by Harsha R Mundaragi on 16/12/22.
//

import Foundation


class UserDataModel {
    
    var userName: String
    var userId: Int
    
    init(userName: String,userId: Int) {
        self.userName = userName
        self.userId = userId
    }
    
    
}
