//
//  TabBarViewController.swift
//  i-LeanAppAssessment
//
//  Created by Harsha R Mundaragi on 08/12/22.
//

import UIKit

class TabBarViewController: UITabBarController {

    var objectOfNavigationController: UINavigationController?

    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        // Do any additional setup after loading the view.
    }


}
